#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>

#define PORT 50007
#define MAX 1024

typedef struct nodoUtente{
	char username[50];
	char password[50];
	int tipo; //1=studente, 2=agente
	struct nodoUtente * next;
}Utente;

typedef struct nodoTicket{
	int categoria;
	char titolo[31];
	char descrizione[501];
	struct tm data_creazione;
	int priorita; //1=bassa, 2=media, 3=alta
	int stato; //1=aperto, 2=in corso, 3=chiuso
	char agente[51];
	char studente[51];
	struct nodoTicket * next;
}Ticket;

void toDo(int connection, char * clientIP);
Utente * caricaUtenti();
Ticket * caricaTicket();
void registrazione(int connectSocket, Utente * primoUtente);
void salvaUtenti(Utente * primoUtente);
Utente * login(int connectSocket, Utente * primoUtente);
void menuStudente(int connectSocket, Ticket * primoTicket, Utente * user);
void menuAgente(int connectSocket, Ticket * primoTicket, Utente * primoUtente, Utente * user);
void apriNuovoTicket(int connectSocket,Ticket * head, Utente * user);
Utente * assegnazioneAutomatica();
int contaTicket(Utente * agente);
void visualizzaTicket(int connectSocket, Ticket * primoTicket);
Ticket *filtraTicketPerUtente(Ticket *primo, Utente *utente);
void stampaListaTicket(Ticket * primo);
char *nomeCategoria(int categoria);
char *nomeStato(int stato);
void ricercaTicket(int connectSocket, Ticket *head, Utente *user);
Ticket* aggiungiTicketAllaLista(Ticket* head, Ticket* originale);
void inviaDettagliTicket(int connectSocket, Ticket *matchList, int sceltaTicket);
void assegnaTicket(int connectSocket, Ticket *headTicket, Utente *headUtente, Utente *utenteLoggato);
void modificaTicket(int connectSocket, Ticket *headTicket, Utente *utenteLoggato);


