#include"client.h"

int main(int argc, char * argv[]){
	int clientSocket;
	struct sockaddr_in servaddr;
	struct sockaddr* serverSockPtr;
	serverSockPtr=(struct sockaddr*)&servaddr;
	clientSocket=socket(AF_INET, SOCK_STREAM, 0); //Creazione socket del client
	if (clientSocket==-1){
		printf("Fallimento nella creazione della socket \n");
		exit(-1);
	}
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr=htonl(INADDR_LOOPBACK); //Indirizzo IP 127.0.0.1
	servaddr.sin_port=htons(PORT); //Porta a cui connettersi
	if((connect(clientSocket, serverSockPtr, sizeof(servaddr)))!=0){
		printf("Connessione con il server fallita\n");
		exit(-1);
	}
	else{
		printf("CONNESSO AL SERVER\n");
		toDo(clientSocket);
		system("clear");
		}
	close(clientSocket);
	return 0;
}

void toDo(int clientSocket){ //Funzione che gestisce il menu di accesso
	int scelta =0;//Scelta dell'operazione da svolgere
	char input[2048];//Stringa in cui vengono memorizzati gli input da tastiera
	int tipoUtente=-1; //Indica nessun utente presente
	char username[31];
	
	for(;;){
		system("clear");
		printf("Benvenuto nel sistema di ticketing!\n");
		sleep(1);
		printf("%s", testoToDo);
		scanf("%s", input);
		//Verifico la validità dell'input (si può scegliere solo 1 o 2)
        	while (!valido(input)||atoi(input)>2||atoi(input)<1) {
        		system("clear");
            		printf("Scelta non valida\n");
            		sleep(1);
			printf("%s", testoToDo);
			scanf("%s", input);
       		}

        	scelta = atoi(input); //Converto la stringa di input in intero per selezionare l'operazione con lo switch
		write(clientSocket, &scelta, sizeof(scelta));
		switch(scelta){
			case 1:
				registrazione(clientSocket);
				printf("%s", ritornoMenu);
				getchar();
				while(getchar()!='\n'); //Per tornare al menu principale bisogna premere INVIO
				break;
			case 2:
				tipoUtente=login(clientSocket); 
				if(tipoUtente==-1 || tipoUtente==0) break;
				read(clientSocket, username, sizeof(username));
				if(tipoUtente==1)
					menuStudente(clientSocket, username);
				if(tipoUtente==2)
					menuAgente(clientSocket, username);
				//Da questo punto non si torna più nel menu di accesso se non con il logout
		}		
	}		
}


int valido(char *stringa) { //Funzione che verifica la validità di un input numerico
	for (int i = 0; stringa[i] != '\0'; i++) {
		if (!isdigit(stringa[i])) {
			return 0;
		}
	}
	return 1; 
}

void registrazione(int clientSocket){ //Richiede i dati del nuovo utente
	int risultato=0; //Serve a comunicare con il server per sapere se l'username inserito non è già presente
	char scelta; //Scelta del tipo di utente
	char codice; //Codice dato come input per registrarsi come agente
	char * username=(char*) malloc(31 * sizeof(char));
	char * password=(char*) malloc(101 * sizeof(char));
	int * tipoUtente = (int*) malloc(sizeof(int));
	
	system("clear");
	printf("MENU DI REGISTRAZIONE\n");
	
	while(risultato==0){
		printf("\nInserire username (spazi non ammessi): \n");
		scanf(" %s", username);
		while(strlen(username)>30){
			printf("\nL'USERNAME DEVE ESSERE AL MASSIMO 30 CARATTERI\n");
			printf("Inserire username (spazi non ammessi): \n");
			scanf(" %s", username);
		}
		write(clientSocket, username, 30);
		read(clientSocket, &risultato, sizeof(risultato));
		while(risultato==0){
			printf("Utente già presente. Cambiare username.");
			printf("Inserire username (spazi non ammessi): \n");
			scanf(" %s", username);
			while(strlen(username)>30){
				printf("\nL'USERNAME DEVE ESSERE AL MASSIMO 30 CARATTERI\n");
				printf("Inserire username (spazi non ammessi): \n");
				scanf(" %s", username);
			}
			write(clientSocket, username, 30);
			read(clientSocket, &risultato, sizeof(risultato));
		}
		
		printf("\nInserire password (spazi non ammessi): \n");
		scanf("%s", password);
		while(strlen(password)>100){
			printf("\nLA PASSWORD DEVE ESSERE AL MASSIMO 100 CARATTERI\n");
			printf("Inserire password (spazi non ammessi): \n");
			scanf("%s", password);
		}
		
		printf("%s", testoTipoUtente);
		scanf("%s", &scelta);
		while (!valido(&scelta)||atoi(&scelta)>2||atoi(&scelta)<1) {
            		printf("Scelta non valida\n");
            		sleep(1);
			printf("%s", testoTipoUtente);
			scanf("%s", &scelta);
       		}
       		*tipoUtente=atoi(&scelta);
       		if(atoi(&scelta)==2){
       			printf("\nInserire codice PIN della segreteria:\n");
			scanf("%s", &codice);
			while(atoi(&codice)!=PIN){
				printf("%s", pinErrato);
				sleep(1);
				printf("\nInserire codice PIN della segreteria:\n");
				scanf("%s", &codice);
			}
       		}
       		
		write(clientSocket, password, 100);  
		write(clientSocket, tipoUtente, sizeof(int));
		system("clear");
	}
	printf("UTENTE REGISTRATO. DA ORA PUOI ACCEDERE TRAMITE LOGIN\n");
	sleep(2);
	
	return;
}

int login(int clientSocket){ //Gestisce l'accesso e restituisce, in caso di successo, il tipo di client che si è autenticato
	int risultato=0;//Comunica l'esito del login
	int try=3;//Tentativi per effettuare il login
	char * username=(char*) malloc(31 * sizeof(char));
	char * password=(char*) malloc(101 * sizeof(char));
	
	system("clear");
	printf("MENU DI LOGIN\n");
	
	while(risultato == 0 && try > 0){
		printf("\nInserire username: \n");
		scanf("%s", username);
		
		printf("\nInserire password: \n");
		scanf("%s", password);
		
		write(clientSocket, username, 30);
		write(clientSocket, password, 100);  
		read(clientSocket, &risultato, sizeof(risultato));
		if(risultato==-1){
			printf("\n\nAl momento non ci sono utenti registrati, si prega di registrarsi prima.\n");
			printf("%s", ritornoMenu);
			getchar();
			while(getchar()!='\n'); //Per tornare al menu principale bisogna premere INVIO
			return risultato;
		}
		try--;
		system("clear");
		if(risultato==0 && try>0)
			printf("USERNAME E PASSWORD SBAGLIATE. Tentativi rimanenti: %d\n\n", try);
		if(risultato>0)
			break;
	}
	if(try==0 && risultato==0){
		printf("TENTATIVI TERMINATI. IMPOSSIBILE EFFETTUARE IL LOGIN\n\n");
		sleep(2);
	}
	if(risultato>0){
		printf("ACCESSO CONSENTITO\n\n");
		sleep(2);
	}
	return risultato;
}

void menuStudente(int clientSocket, char * username){ //Gestisce le operazioni disponibili per gli studenti
	char input[2048];
	int scelta=0;
	
	for(;;){
		system("clear");
		printf("MENU STUDENTE\n\n");
		sleep(1);
		printf("%s", testoMenuStudente); //Opzioni operazioni
		scanf("%s", input);
		system("clear");
		while (!valido(input)||atoi(input)>4||atoi(input)<1) {
        		system("clear");
            		printf("Scelta non valida\n");
            		sleep(1);
			printf("%s", testoMenuStudente);
			scanf("%s", input);
       		}
       		scelta=atoi(input);
       		write(clientSocket, &scelta, sizeof(scelta));
       		
       		switch(scelta){
       			case 1:
       				apriNuovoTicket(clientSocket);
       				printf("%s", ritornoMenu);
				getchar();
				while(getchar()!='\n'); //Per tornare al menu principale bisogna premere INVIO
       				break;
       			case 2:
       				visualizzaTicket(clientSocket);
       				printf("%s", ritornoMenu);
				getchar();
				while(getchar()!='\n'); //Per tornare al menu principale bisogna premere INVIO
       				break;
       			case 3:
       				ricercaTicket(clientSocket);
       				printf("%s", ritornoMenu);
				getchar();
				while(getchar()!='\n'); //Per tornare al menu principale bisogna premere INVIO
       				break;
       			case 4:
       				int conferma = logout(clientSocket); //Viene chiesto all'utente se è sicuro della sua scelta
		       		if(conferma == 1) {
		       			system("clear");
		       			printf("Grazie per aver usato il nostro sistema di ticketing. A presto!\n");
		       			sleep(2);
		       			return;
		       		}
		       		else{
		       			system("clear");
	       				break;
	       			}
       		}
	}
	
}

void menuAgente(int clientSocket, char *username){ //Gestisce le operazioni disponibili per gli agenti
	char input[2048];
	int scelta=0;
	
	for(;;){
		system("clear");
		printf("MENU AGENTE\n\n");
		sleep(1);
		printf("%s", testoMenuAgente); //Opzioni operazioni
		scanf("%s", input);
		system("clear");
		while (!valido(input)||atoi(input)>5||atoi(input)<1) {
        		system("clear");
            		printf("Scelta non valida\n");
            		sleep(1);
			printf("%s", testoMenuAgente);
			scanf("%s", input);
       		}
       		scelta=atoi(input);
       		write(clientSocket, &scelta, sizeof(scelta));
       		
       		switch(scelta){
       			case 1:
       				visualizzaTicket(clientSocket);
       				printf("%s", ritornoMenu);
				getchar();
				while(getchar()!='\n'); //Per tornare al menu principale bisogna premere INVIO
       				break;
       			case 2:
       				ricercaTicket(clientSocket);
       				printf("%s", ritornoMenu);
				getchar();
				while(getchar()!='\n'); //Per tornare al menu principale bisogna premere INVIO
       				break;
       			case 3:
       				assegnaTicket(clientSocket);
       				break;
       			case 4: 
       				modificaTicket(clientSocket);
       				break;
       			case 5:
       				int conferma = logout(clientSocket); //Viene chiesto all'utente se è sicuro della sua scelta
		       		if(conferma == 1) {
		       			system("clear");
		       			printf("Grazie per aver usato il nostro sistema di ticketing. A presto!\n");
		       			sleep(2);
		       			return;
		       		}
		       		else{
		       			system("clear");
	       				break;
	       			}
       		}
	}
}

void apriNuovoTicket(int clientSocket){
	char input[2048];
	int scelta=0;
	char titolo[31];
	char descrizione[501];
	printf("%s", testoCategoriaTicket);
	scanf("%s", input);
	while(!valido(input) || atoi(input)<1 || atoi(input)>5){
		system("clear");
		printf("Scelta non valida.\n");
		sleep(1);
		printf("%s", testoCategoriaTicket);
		scanf("%s", input);
	}
	scelta=atoi(input);
	
	printf("\n\nInserisci il titolo del ticket: ");
	scanf(" %[^\n]", titolo);
	while(strlen(titolo)>30){
		system("clear");
		printf("Il titolo del ticket deve essere massimo di 30 caratteri. Riprovare:\n\n");
		scanf(" %[^\n]",titolo);
	}
	
	printf("\n\nDescrivi il problema: \n");
	scanf(" %[^\n]", descrizione);
	while(strlen(descrizione)>500){
		system("clear");
		printf("La descrizione del problema deve essere massimo di 500 caratteri. Riprovare:\n\n");
		scanf(" %[^\n]",descrizione);
	}
	
	char buff[sizeof(int) + 31 + 501]; //Buffer su cui vengono copiati i dati da passare al server
	
	memcpy(buff, &scelta, sizeof(int));
	memcpy(buff + sizeof(int), titolo, 31);
	memcpy(buff + sizeof(int) + 31, descrizione, 501);

	write(clientSocket, buff, sizeof(buff));
	
	int risultato=0;
	read(clientSocket, &risultato, sizeof(int)); //Indica se è stato trovato un agente a cui assegnare il ticket
	if(strlen(titolo)>0 && strlen(descrizione)>0 && risultato == 1){
		system("clear");
		printf("Ticket creato correttamente.\n");
		sleep(1);
	} else{
		printf("\nNon ci sono ancora agenti a cui assegnare il ticket, ticket non creato.\n");
		sleep(1);
	}
	return;
}

void visualizzaTicket(int clientSocket) {
	int risultato;
	system("clear");
	printf("I tuoi ticket:\n\n");
	int index=0;
	while (1) {
		read(clientSocket, &risultato, sizeof(risultato));

		if (risultato == 0) {   // lista vuota
			printf("NESSUN TICKET ESISTENTE\n");
			return;
		}

		if (risultato == 2)  break; // fine lista

		if (risultato == 1) {   // ticket valido
			char titolo[31];
			char categoria[41];
			char stato[11];
			index++; // Indice del ticket
			
			// Ricevo i campi
			read(clientSocket, titolo, 30);
			titolo[30] = '\0';

			read(clientSocket, categoria, 40);
			categoria[40] = '\0';

			read(clientSocket, stato, 10);
			stato[10] = '\0';

			// Stampo il ticket
			printf("Ticket num.: %d\nTitolo: %s\nCategoria: %s\nStato: %s\n\n", index, titolo, categoria, stato);
		}
	}
	// Scelta del ticket
	int sceltaTicket;
	char idTicket[2048];
	printf("\nSeleziona il numero del ticket per vedere i dettagli (0 per uscire): ");
	scanf("%s", idTicket);
	while(!valido(idTicket) || atoi(idTicket)<0 || atoi(idTicket)>index){
		printf("\nScelta non valida.");
		printf("\nSeleziona il numero del ticket per vedere i dettagli (0 per uscire): ");
		scanf("%s", idTicket);
	}
	sceltaTicket=atoi(idTicket);
	write(clientSocket, &sceltaTicket, sizeof(sceltaTicket)); // Comunico di quale ticket voglio avere i dettagli

	if (sceltaTicket > 0) {
		stampaDettagliTicket(clientSocket);
	}
}

void ricercaTicket(int clientSocket) {
    	char input[2048];
	char titolo[31];
	char * data;
	char categoria[11];
	char stato[11];
	int scelta;// Scelta del parametro di ricerca
	int risultato = 0;
	
	system("clear");
	printf("MENU DI RICERCA\n\n");
	sleep(1);
	printf("%s", testoRicerca);
	scanf("%s", input);
	
	while (!valido(input) || atoi(input) > 4 || atoi(input) < 1) {  
		system("clear");
		printf("Scelta non valida.\n\n");
		sleep(1);
		printf("%s", testoRicerca);
		scanf("%s", input);
	}
	
	scelta = atoi(input);
	write(clientSocket, &scelta, sizeof(scelta));
	
	switch(scelta){
		case 1://Per titolo
			printf("Inserire titolo (o parte del titolo):\n");
			scanf(" %[^\n]",titolo);
			write(clientSocket, titolo, 30);
			break;
			
		case 2://Per categoria
			int id = 0;
			printf("%s", testoCategoriaTicket);
			scanf("%s", categoria);
			while (!valido(categoria) || atoi(categoria)>5 || atoi(categoria)<1) {  
				system("clear");
				printf("Scelta non valida. \n\n%s", testoCategoriaTicket);
				scanf("%s", categoria);
			}
			id=atoi(categoria);
			write(clientSocket, &id, sizeof(int));
			break;
		
		case 3://Per data
			char query[11]; // "YYYY-MM-DD" + terminatore
			printf("Inserire la data che stai cercando (formato YYYY-MM-DD): \n");
			scanf("%10s", query);

			while(!leggiData(query)) {
				printf("Formato data non valido!\n");
				printf("Inserire la data che stai cercando (formato YYYY-MM-DD): \n");
				scanf("%s", query);
			}

			write(clientSocket, query, strlen(query)+1);
			break;
		
		case 4://Per stato
			int id2 = 0;
			printf("Seleziona lo stato da ricercare:\n\n1. Aperto\n2. In corso\n3. Chiuso\n\n");
			scanf("%s", stato);
			while (!valido(stato) || atoi(stato)>3 || atoi(stato)<1) {  
				system("clear");
				printf("Scelta non valida. \n\nSeleziona lo stato da ricercare:\n\n1. Aperto\n2. In corso\n3. Chiuso\n\n");
				scanf("%s", stato);
			}
			id2=atoi(stato);
			write(clientSocket, &id2, sizeof(int));
			break;
	}
	system("clear");
	printf("Risultati della ricerca:\n");
	
	int index = 0; //Indice dei ticket
	while (1) {
		read(clientSocket, &risultato, sizeof(risultato));
        	if (risultato==2) 
            		break;  // Non ci sono più dati da leggere
        	if (risultato == 0) {
            		printf("Nessuna corrispondenza trovata.\n");
            		return;
        	} else if (risultato == 1) { //Stampo tutti i risultati
			char titolo_tmp[31];
			char categoria_tmp[41];
			char stato_tmp[11];
			index++;
			
			// Ricevo i campi
			read(clientSocket, titolo_tmp, 30);
			titolo_tmp[30] = '\0';

			read(clientSocket, categoria_tmp, 40);
			categoria_tmp[40] = '\0';

			read(clientSocket, stato_tmp, 10);
			stato_tmp[10] = '\0';

			// Stampo il ticket
			printf("Ticket num.: %d\nTitolo: %s\nCategoria: %s\nStato: %s\n\n", index, titolo_tmp, categoria_tmp, stato_tmp);   	
		}
    	}
    	
    	// Scelta del ticket
	int sceltaTicket;
	char idTicket[2048];
	printf("\nSeleziona il numero del ticket per vedere i dettagli (0 per uscire): ");
	scanf("%s", idTicket);
	while(!valido(idTicket) || atoi(idTicket)<0 || atoi(idTicket)>index){
		printf("\nScelta non valida.");
		printf("\nSeleziona il numero del ticket per vedere i dettagli (0 per uscire): ");
		scanf("%s", idTicket);
	}
	sceltaTicket=atoi(idTicket);
	write(clientSocket, &sceltaTicket, sizeof(sceltaTicket)); // Comunico di quale ticket voglio avere i dettagli

	if (sceltaTicket > 0) {
		stampaDettagliTicket(clientSocket);
	}
}

int leggiData(char *buffer) {
	int year, month, day;
	if (sscanf(buffer, "%4d-%2d-%2d", &year, &month, &day) != 3) {
		return 0; // Formato errato
	}
	if (year < 1900 || month < 1 || month > 12 || day < 1 || day > 31) {
		return 0; // Valori non validi
	}
	return 1; // Valido
}

int logout(int clientSocket){ //Restituisce la conferma di logout dell'utente
	system("clear");
	int conferma = 0;
	char inputLogout[2048];
	printf("Sei sicuro di voler effettuare il logout?\n\n1. SI\n2. NO\n\n");
	scanf("%s", inputLogout);
	while (!valido(inputLogout)||atoi(inputLogout)>2||atoi(inputLogout)<1) {
		system("clear");
    		printf("Scelta non valida\n\n");
    		sleep(1);
		printf("Sei sicuro di voler effettuare il logout?\n\n1. SI\n2. NO\n\n");
		scanf("%s", inputLogout);
	}
	conferma = atoi(inputLogout);
	write(clientSocket, &conferma, sizeof(int));
	return conferma;
}

void stampaDettagliTicket(int clientSocket){ //Riceve tutti i campi di un ticket dal server e li stampa
	char titolo[31], descrizione[501], categoria[40], stato[10], studente[51], agente[51], data[11];
	read(clientSocket, titolo, sizeof(titolo));
	read(clientSocket, descrizione, sizeof(descrizione));
	read(clientSocket, categoria, sizeof(categoria));
	read(clientSocket, stato, sizeof(stato));
	read(clientSocket, studente, sizeof(studente));
	read(clientSocket, agente, sizeof(agente));
	read(clientSocket, data, sizeof(data));

	printf("\n--- Dettagli Ticket ---\n");
	printf("Titolo: %s\n", titolo);
	printf("Descrizione: %s\n", descrizione);
	printf("Categoria: %s\n", categoria);
	printf("Stato: %s\n", stato);
	printf("Studente: %s\n", studente);
	printf("Agente: %s\n", agente);
	printf("Data creazione: %s\n", data);
	printf("-----------------------\n");
}

void assegnaTicket(int clientSocket) { //Stampa la lista di ticket di un agente, l'agente ne seleziona uno e inserisce il nome dell'agente a cui vuole riassegnarlo
	int numTicket, scelta, risultato;
	char nuovoAgente[31], input[2048];
	
	write(clientSocket, "LISTA_TICKET", 13);
	
	int count = 0;
	read(clientSocket, &count, sizeof(int)); //Ricevo il numero di ticket dell'agente

	if (count == 0) {
		printf("Non ci sono ticket assegnati a te.\n");
		return;
	}

	char titolo[31];
	for (int i = 0; i<count; i++) {
		read(clientSocket, titolo, 31);
		printf("Ticket num.: %d\n %s\n\n", i+1, titolo);
	}

	printf("Seleziona il numero del ticket da riassegnare: ");
	scanf("%s", input);

	while (!valido(input) || atoi(input)<1 || atoi(input)>count) {
		printf("Scelta non valida. Reinserisci: ");
		scanf("%s", input);
	}
	scelta=atoi(input);
	write(clientSocket, &scelta, sizeof(int)); //Comunico il ticket da riassegnare

	printf("Inserisci il nome dell’agente a cui riassegnare: ");
	scanf("%s", nuovoAgente);
	write(clientSocket, nuovoAgente, 31); //Comunico il nuovo agente

	read(clientSocket, &risultato, sizeof(int)); //Esito dell'assegnazione

	if (risultato == 1) {
		system("clear");
		printf("Ticket riassegnato con successo!\n");
		sleep(2);
	} else {
		system("clear");
		printf("Errore: agente non trovato.\n");
		printf("%s", ritornoMenu);
		getchar();
		while(getchar()!='\n'); //Per tornare al menu principale bisogna premere INVIO
	}
}

void modificaTicket(int clientSocket) {
	int count = 0, sceltaTicket, sceltaCampo, nuovoValore, risultato;
	char comando[20] = "LISTA_TICKET";

	write(clientSocket, comando, sizeof(comando));

	read(clientSocket, &count, sizeof(int)); //Ricevo il numero di ticket dell'agente
	if (count == 0) {
		printf("Non hai ticket assegnati.\n");
		return;
	}

	char titolo[31];
	for (int i = 0; i < count; i++) {
		read(clientSocket, titolo, 31);
		printf("Ticket num.: %d\n %s\n\n", i+1, titolo);
	}
	
	char inputScelta[10];
	printf("Seleziona il numero del ticket da modificare: ");
	scanf("%s", inputScelta);
	while (!valido(inputScelta) ||atoi(inputScelta) < 1 || atoi(inputScelta) > count) {
		printf("Scelta non valida. Reinserisci: ");
		scanf("%s", inputScelta);
	}
	sceltaTicket=atoi(inputScelta);
	write(clientSocket, &sceltaTicket, sizeof(int)); //Comunico il ticket da riassegnare
	
	char inputCampo[10];
	printf("Seleziona il campo da modificare:\n1) Stato\n2) Priorità\n\n");
	scanf("%s", inputCampo);
	while (!valido(inputCampo) ||atoi(inputCampo)<1 || atoi(inputCampo) > 2) {
		printf("Scelta non valida. Reinserisci (1 o 2): ");
		scanf("%s", inputCampo);
	}
	sceltaCampo=atoi(inputCampo);
	write(clientSocket, &sceltaCampo, sizeof(int)); //Comunico il campo da modificare (1=stato, 2=priorità)
	
	char inputValore[10];
	if (sceltaCampo == 1) {
		printf("Inserisci nuovo stato (1=Aperto, 2=In corso, 3=Chiuso): ");
		scanf("%s", inputValore);
		while (!valido(inputValore) ||atoi(inputValore)<1 || atoi(inputValore) > 3) {
			printf("Valore non valido. Reinserisci (1-3): ");
			scanf("%s", inputValore);
		}
	} else {
		printf("Inserisci nuova priorità (1=Bassa, 2=Media, 3=Alta): ");
		scanf("%s", inputValore);
		while (!valido(inputValore) ||atoi(inputValore)<1 || atoi(inputValore) > 3) {
			printf("Valore non valido. Reinserisci (1-3): ");
			scanf("%s", inputValore);
		}
	}
	nuovoValore=atoi(inputValore);
	write(clientSocket, &nuovoValore, sizeof(int)); //Comunico il nuovo valore

	read(clientSocket, &risultato, sizeof(int));
	if (risultato == 1) {
		system("clear");
		printf("Ticket modificato con successo!\n");
		sleep(2);
	} else {
		system("clear");
		printf("Errore: impossibile modificare il ticket.\n");
		printf("%s", ritornoMenu);
		getchar();
		while(getchar()!='\n'); //Per tornare al menu principale bisogna premere INVIO
	}
}

