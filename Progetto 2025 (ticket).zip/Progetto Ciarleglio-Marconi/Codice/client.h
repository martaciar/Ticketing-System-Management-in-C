#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>

#define PORT 50007

void toDo(int clientSocket);
int valido(char *stringa);
void registrazione(int clientSocket);
int login(int clientSocket);
void menuStudente(int clientSocket, char *nome);
void menuAgente(int clientSocket, char *nome);
void apriNuovoTicket(int clientSocket);
void visualizzaTicket(int clientSocket);
void ricercaTicket(int clientSocket);
int leggiData(char *buffer);
int logout(int clientSocket);
void stampaDettagliTicket(int clientSocket);
void assegnaTicket(int clientSocket);
void modificaTicket(int clientSocket);

char* testoToDo="Selezionare un'opzione di accesso:\n1. Registrazione\n2. Login\n\n\n";
char* ritornoMenu="\n\nPremere invio per tornare al menu principale";
char* testoTipoUtente="\nSelezionare il tipo di utente da creare: \n1. Studente \n2. Agente\n\n\n";
char* testoMenuStudente="Selezionare l'operazione da svolgere:\n1. Apri un nuovo ticket \n2. Visualizza i tuoi ticket \n3. Ricerca un ticket \n4. Logout\n\n";
char* testoMenuAgente="Selezionare l'operazione da svolgere:\n1. Visualizza i tuoi ticket \n2. Ricerca un ticket \n3. Assegna un ticket \n4. Modifica un ticket \n5. Logout\n\n";
char* testoCategoriaTicket="Seleziona la categoria del ticket:\n1. Tasse universitarie \n2. Gestione carriera \n3. Problemi di accesso al libretto \n4. Supporto per studenti internazionali \n5. Altro\n\n";
char* testoRicerca="Seleziona il parametro in base a cui vuoi effettuare la ricerca del ticket:\n\n1. Titolo \n2. Categoria \n3. Data creazione \n4. Stato\n\n";

#define PIN 1234
char* pinErrato="\nIl codice PIN per registrarsi come utente è errato, si prega di riprovare.\n";
