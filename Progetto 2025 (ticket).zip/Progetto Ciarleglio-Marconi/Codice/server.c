#include"server.h"

int main(int argc, char * argv[]){
	system("clear");
	int serverSocket, connectSocket;
	socklen_t clientAddressLen;
	struct sockaddr_in servaddr, client;
	struct sockaddr* serverSockPtr;
	int returnCode;
	char *clientIP;
	serverSockPtr=(struct sockaddr*)&servaddr;
	struct sockaddr* clientSockPtr;
	clientSockPtr=(struct sockaddr*)&client;
	serverSocket=socket(AF_INET, SOCK_STREAM, 0);
	if (((serverSocket=socket(AF_INET, SOCK_STREAM, 0)))==-1){
		printf("Fallimento nella creazione della socket \n");
		exit(-1);
	}
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
	servaddr.sin_port=htons(PORT);
	if((returnCode=bind(serverSocket, serverSockPtr, sizeof(servaddr)))==-1){
		printf("Fallimento della bind\n");
		exit(-1);
	}
	if((listen(serverSocket, 1))!=0){
		printf("Listen fallita\n");
		exit(-1);
	}
	else
		printf("Server in ascolto (CTRL-C per terminare)\n");
	clientAddressLen=sizeof(client);
	while(1){ //Server sempre in ascolto
		connectSocket=accept(serverSocket, clientSockPtr, &clientAddressLen);
		if(connectSocket<0){
			printf("Accept fallita\n");
			exit(-1);
		}
		else 
			printf("Server accetta il client\n");
		if(fork()==0){
			clientIP=inet_ntoa(client.sin_addr);
			printf("\nClient @ %s connects on socket %d\n", clientIP, connectSocket);
			toDo(connectSocket, clientIP);
			close(connectSocket);
			exit(-1);
		}
		else{
			close(connectSocket);
		}
	}
	close(serverSocket);
	return 0;
}

void toDo(int connectSocket, char* clientIP){ //Funzione che gestisce il menu di accesso
	char buff[MAX];
	Utente * user=(Utente * ) malloc (sizeof(Utente));
	int tipoUtente=0;
	for(;;){
		int scelta=0; //Variabile che definisce quale operazione dovrà essere svolta
		read(connectSocket, &scelta, sizeof(scelta)); //Inserisce in scelta l'opzione selezionata dal client
		if(scelta==0){
			printf("Client @ %s disconnesso\n", clientIP);
			close(connectSocket);
			return;
		}
		else if(scelta<0){
			perror("Errore in read");
    			close(connectSocket);
    			return;
		}
		
		Utente * primoUtente=caricaUtenti(); 
		Ticket * primoTicket=caricaTicket();
		//Le liste di utenti e ticket vengono aggiornate
		
		switch(scelta){
			case 1:
				registrazione(connectSocket, primoUtente);
				break;
			case 2:
				user=login(connectSocket, primoUtente);
				if(user == NULL) break; //Se il login non è andato a buon fine
				tipoUtente = user->tipo;
				printf("Utente loggato di tipo: %d\n",tipoUtente); 
				
				if(tipoUtente==1){
					menuStudente(connectSocket, primoTicket, user);
				}
				if(tipoUtente==2){
					menuAgente(connectSocket, primoTicket, primoUtente, user);
				}
				break;
		}
		
	}
}

Utente * caricaUtenti() { //Funzione che restituisce il primo nodo (fittizio) della lista di utenti
	FILE *file = fopen("Utenti.txt", "rb");
	
	//Nodo fittizio
	Utente *primoUtente = (Utente *) malloc(sizeof(Utente));
	primoUtente->next = NULL;
	primoUtente->username[0] = '\0';
	primoUtente->password[0] = '\0';

	if (file == NULL) { //File non esistente
		return primoUtente;
	}

	Utente *current = primoUtente;
	while (1) {
		Utente *tmp = (Utente *) malloc(sizeof(Utente));
		if (fread(tmp, sizeof(Utente) - sizeof(Utente *), 1, file) != 1) {
			free(tmp);
			break;
		}
		tmp->next = NULL;
		current->next = tmp;
		current = tmp;
	}

	fclose(file);
	return primoUtente; 
}

Ticket *caricaTicket() { //Funzione che restituisce il primo nodo (fittizio) della lista di ticket
	FILE *file = fopen("Ticket.txt", "rb");
	
	//Nodo fittizio
	Ticket *primoTicket = malloc(sizeof(Ticket));
	primoTicket->next = NULL;
	primoTicket->titolo[0] = '\0';
	primoTicket->descrizione[0] = '\0';

	if (file == NULL) { //File non esistente
		return primoTicket;
	}

	Ticket *current = primoTicket;
	while (1) {
		Ticket *tmp = malloc(sizeof(Ticket));
		if (fread(tmp, sizeof(Ticket) - sizeof(Ticket *), 1, file) != 1) {
			free(tmp);
			break;
		}
		tmp->next = NULL;
		current->next = tmp;
		current = tmp;
	}
	fclose(file);
	return primoTicket;
}


Ticket *filtraTicketPerUtente(Ticket *primo, Utente *utente) { //Data la lista di ticket, restituisce una nuova lista che contiene solo i ticket dell'utente "utente"
	Ticket *nuovaLista = NULL;     
	Ticket *last = NULL; //Puntatore all'ultimo nodo

	Ticket *current = primo->next; // Salto il nodo sentinella 
	while (current != NULL) {
		if (strcmp(current->studente, utente->username) == 0 || strcmp(current->agente, utente->username) == 0) {
			Ticket *copia = malloc(sizeof(Ticket));
			if (!copia) {
				perror("malloc");
				return nuovaLista; 
			}
			*copia = *current; // Copia campo per campo 
			copia->next = NULL;

			if (nuovaLista == NULL) {
				nuovaLista = copia;
				last = copia;
			} else {
				last->next = copia;
				last = copia;
			}
		}
		current = current->next;
	}

	return nuovaLista;
}

void stampaListaTicket(Ticket * primo){  //Utile per i test
	Ticket *c = primo;
	int i=1;
	while (c != NULL) {
		printf("Ticket %d, titolo: %s\n", i, c->titolo);
		c = c->next;
		i++;
	}
}

void registrazione(int connectSocket, Utente * primoUtente){ 
	int risultato=0;//Risultato della registrazione
	char username[31];
	char password[101];
	int tipo;
	Utente * tmp=primoUtente;
	
	while(risultato==0){//Verifica che nella lista non ci sia già un altro utente con lo stesso username ricevuto
		tmp=primoUtente;
		Utente * current=tmp->next;
		risultato=1;
		read(connectSocket, username, 30);
		
		while (current != NULL) {
	    		if (strcmp(current->username, username) == 0) {
				risultato = 0;
				break;
	    		}
	    		tmp=current;
	    		current = current->next;
		}
		write(connectSocket, &risultato, sizeof(risultato));
	}
	read(connectSocket, password, 100);
	read(connectSocket, &tipo, sizeof(int));
	
	//Aggiunge il nuovo utente in fondo alla lista
	Utente * inserisci=(Utente *)malloc(sizeof(Utente));
	strcpy(inserisci->username,username);
	strcpy(inserisci->password,password);
	inserisci->tipo=tipo;
	inserisci->next=NULL;
	tmp->next=inserisci;
	if(strlen(username)>0 && strlen(password)>0 && tipo!=0)
		salvaUtenti(primoUtente); //Aggiorna il file
	return;
}


void salvaUtenti(Utente * primoUtente){ //Funzione che aggiorna il file che contiene gli utenti
    	remove("Utenti.txt");
    	FILE *file = fopen("Utenti.txt", "wb");
    	if (file == NULL) {
        	perror("Errore nell'apertura del file per la scrittura");
        	return;
    	}

    	Utente * current = primoUtente;
    	while (current != NULL) {
        	fwrite(current, sizeof(Utente) - sizeof(Utente *), 1, file);
        	current = current->next;
    	}

    	fclose(file);
	return;
}

void salvaTicket(Ticket * primoTicket) { //Funzione che aggiorna il file che contiene i ticket
	remove("Ticket.txt");
	FILE *file = fopen("Ticket.txt", "wb");
	if (file == NULL) {
		perror("Errore nell'apertura del file per la scrittura");
		return;
	}

	Ticket *current = primoTicket->next;
	while (current != NULL) {
		fwrite(current, sizeof(Ticket) - sizeof(Ticket *), 1, file);
		current = current->next;
	}

	fclose(file);
	return;
}


Utente * login(int connectSocket, Utente * primoUtente){
	int risultato=0;//Risultato del login
	char username[31];
	char password[101];
	int try=3;//Tentativi
	Utente * tmp=primoUtente;
	while(risultato == 0 && try > 0){
		Utente * current=primoUtente->next;
		read(connectSocket, username, 30);
		read(connectSocket, password, 100);
		if(current == NULL){ 
			printf("Nessun utente presente.\n");
			risultato = -1;
			write(connectSocket, &risultato, sizeof(risultato));
			return NULL;
		}
		while (current != NULL) { //Confronto con utenti esistenti
	    		if (strcmp(current->username, username) == 0 && strcmp(current->password, password) == 0) {
				risultato = current->tipo;
				break;
	    		}
	    		tmp=current;
	    		current = current->next;
		}
		write(connectSocket, &risultato, sizeof(risultato));
		try--;
		if(risultato>0){
			write(connectSocket, &username, sizeof(username));
			return current;
		} 
	}
	return NULL;
}

void menuStudente(int connectSocket, Ticket * primoTicket, Utente * user){ //Funzione che gestisce le operazioni degli studenti
	int scelta=0; //Scelta dell'operazione
	printf("\n\nMenu studente\n");
	for(;;){
		primoTicket = caricaTicket(); //Aggiorna i ticket ad ogni operazione
		Ticket * listaStudente = filtraTicketPerUtente(primoTicket, user);
		read(connectSocket, &scelta, sizeof(scelta)); //Inserisce in scelta l'opzione selezionata dal client
		switch(scelta){
			case 1:
				apriNuovoTicket(connectSocket, primoTicket, user);
				break;
			case 2:
				visualizzaTicket(connectSocket, listaStudente);
				break;
			case 3:
				ricercaTicket(connectSocket, listaStudente, user);
				break;
			case 4:
				int conferma = 0;
				read(connectSocket, &conferma, sizeof(int));
				if(conferma==2) break;
				else{
					printf("Utente %s ha effettuato il logout\n", user->username);
					return;
				}
		}
	}
}

void menuAgente(int connectSocket, Ticket * primoTicket, Utente * primoUtente, Utente * user){ //Funzione che gestisce le operazioni degli studenti
	int scelta=0; //Scelta dell'operazione
	printf("\n\nMenu agente\n");
	
	for(;;){
		Ticket * listaAgente = filtraTicketPerUtente(primoTicket, user);
		read(connectSocket, &scelta, sizeof(scelta)); //Inserisce in scelta l'opzione selezionata dal client
		switch(scelta){
			case 1:
				visualizzaTicket(connectSocket, listaAgente);
				break;
			case 2:
				ricercaTicket(connectSocket, listaAgente, user);
				break;
			case 3:
				assegnaTicket(connectSocket, primoTicket, primoUtente, user);
				break;
			case 4:
				modificaTicket(connectSocket, primoTicket, user);
				break;
			case 5:
				int conferma = 0;
				read(connectSocket, &conferma, sizeof(int));
				if(conferma==2) break;
				else{
					printf("Utente %s ha effettuato il logout\n", user->username);
					return;
				}
		}
	}
}

void apriNuovoTicket(int connectSocket, Ticket *head, Utente* user) {
	char buff[sizeof(int) + 31 + 501];
	int categoria=0;
	char titolo[31];
	char descrizione[501];
	int risultato = 1;

	Ticket *tmp = (Ticket *)malloc(sizeof(Ticket));
	if (!tmp) {
		perror("malloc ticket");
		return;
	}

	size_t totalBytes = sizeof(buff);
	size_t bytesRead = 0; //Variabile per sapere quando smettere di leggere dati
	while (bytesRead < totalBytes) {
		ssize_t n = read(connectSocket, buff + bytesRead, totalBytes - bytesRead);
		if (n <= 0) {
			perror("Errore lettura dal socket");
			free(tmp);
			return;
		}
		bytesRead += n;
	}
	
	//Salva i dati ricevuti
	memcpy(&categoria, buff, sizeof(int));

	memcpy(titolo, buff + sizeof(int), 31);
	titolo[30] = '\0';

	memcpy(descrizione, buff + sizeof(int) + 31, 501);
	descrizione[500] = '\0';
	
	//Inserisce i dati ricevuti nel nuovo nodo
	tmp->categoria = categoria;
	strncpy(tmp->titolo, titolo, sizeof(tmp->titolo)-1);
	tmp->titolo[sizeof(tmp->titolo)-1] = '\0';
	strncpy(tmp->descrizione, descrizione, sizeof(tmp->descrizione)-1);
	tmp->descrizione[sizeof(tmp->descrizione)-1] = '\0';
	tmp->next = NULL;
	
	//Dati di default: data di creazione localtime, priorità bassa, stato aperto, studente proprietario (creatore)
	time_t now = time(NULL);
	tmp->data_creazione = *localtime(&now);  
	tmp->priorita = 1;
	tmp->stato = 1;
	strncpy(tmp->studente, user->username, sizeof(tmp->studente)-1);
	tmp->studente[sizeof(tmp->studente)-1] = '\0';
	
	//Assegnazione automatica dell'agente
	Utente *agente = assegnazioneAutomatica();  
	if (agente == NULL) {
		printf("Non ci sono agenti a cui assegnare il ticket.\n");
		risultato=0;
		write(connectSocket, &risultato, sizeof(int));
		free(tmp);
		return;
	}
	write(connectSocket, &risultato, sizeof(int));
	strncpy(tmp->agente, agente->username, sizeof(tmp->agente)-1);
	tmp->agente[sizeof(tmp->agente)-1] = '\0';

	// Inserimento in lista
	if (head->next == NULL) {
		head->next = tmp;
		printf("Ticket aggiunto in testa alla lista\n");
	} else {
		Ticket *current = head;
		int i = 0;
		while (current->next != NULL) {
			i++;
			current = current->next;
		}
		current->next = tmp;
		printf("Ticket con titolo: %s, aggiunto in posizione: %d\n", tmp->titolo, i+1);
	}
	salvaTicket(head); //Aggiorna la lista di ticket
}

Utente * assegnazioneAutomatica(){ //Sceglie l'agente a cui sono assegnati meno ticket
	Utente * primoUtente=caricaUtenti();
	Utente * current = primoUtente->next;
	Utente * scelto = NULL;
	int min=MAX;
	if(current == NULL){
		return NULL;
	}
	while(current != NULL){
		if(current->tipo == 2){
			int n=contaTicket(current);
			if(n<min){
				min=n;
				scelto = current;
			}
		}
		current=current->next;
	}
	if(scelto==NULL){
		return NULL;
	}
	else return scelto;
}

int contaTicket(Utente * utente){  //Conta i ticket di un utente (serve per l'assegnazione automatica)
	Ticket * primoTicket = caricaTicket();
	Ticket * current = primoTicket->next;
	int count=0;
	if(current==NULL)
		return 0;
	else{
		while(current!=NULL){
			if(strcmp(current->agente, utente->username)==0 || strcmp(current->studente, utente->username)==0)
				count++;
			current=current->next;
		}
	}
	return count;
}

void visualizzaTicket(int connectSocket, Ticket *head) { //Funzione che mostra la lista dei propri ticket e permette di selezionarne uno per visualizzarne i dettagli
	int risultato = 0;

	if (head == NULL) {
		write(connectSocket, &risultato, sizeof(risultato));
		return;
	}

	Ticket *current = head;
	while (current != NULL) {
		char cat[40];
		char st[10];

		// Pulisco i buffer
		memset(cat, 0, sizeof(cat));
		memset(st, 0, sizeof(st));

		// Inserisco la categoria e lo stato
		strncpy(cat, nomeCategoria(current->categoria), sizeof(cat) - 1);
		strncpy(st, nomeStato(current->stato), sizeof(st) - 1);

		// Avviso il client che arriva un ticket
		risultato = 1;
		write(connectSocket, &risultato, sizeof(risultato));

		// Invio i campi del ticket
		write(connectSocket, current->titolo, 30);
		write(connectSocket, cat, sizeof(cat));
		write(connectSocket, st, sizeof(st));

		current = current->next;
	}

	risultato = 2; //Fine lista
	write(connectSocket, &risultato, sizeof(risultato));
	
	int sceltaTicket;
	read(connectSocket, &sceltaTicket, sizeof(sceltaTicket));
	if (sceltaTicket > 0) {
		inviaDettagliTicket(connectSocket, head, sceltaTicket);
	}
	return;
}

char *nomeCategoria(int categoria){ //Funzione che, dato un intero, restituisce il nome della categoria corrispondente
	if(categoria==1) return "Tasse universitarie";
	if(categoria==2) return "Gestione carriera";
	if(categoria==3) return "Problemi di accesso al libretto";
	if(categoria==4) return "Supporto per studenti internazionali";
	return "Altro";
}

char *nomeStato(int stato){ //Funzione che, dato un intero, restituisce il nome dello stato corrispondente
	if(stato==1) return "Aperto";
	if(stato==2) return "In corso";
	return "Chiuso";
}

void ricercaTicket(int connectSocket, Ticket *head, Utente *utente) { 
    	Ticket *current = head;  
    	Ticket* listaFiltrata = NULL;
	char tmp[31];
	int id = 0;
	int risultato = 0;  //0 significa che nessun ticket non è stato trovato
	int scelta = 0; //Scelta del parametro di ricerca
	read(connectSocket, &scelta, sizeof(scelta));
        switch (scelta){
		case 1: //Per titolo
			read(connectSocket, tmp, 30);
			while (current != NULL) {
		    		if (strstr(current->titolo, tmp) != NULL) { //Cerca la stringa tmp all'interno dei titoli
					risultato = 1;
					write(connectSocket, &risultato, sizeof(risultato));
					write(connectSocket, current->titolo, 30);
					write(connectSocket, nomeCategoria(current->categoria), 40);
					write(connectSocket, nomeStato(current->stato), 10);
					listaFiltrata = aggiungiTicketAllaLista(listaFiltrata, current);
		   		 }
		    		current = current->next;
			}
			break;
		case 2://Per categoria
			read(connectSocket, &id, sizeof(int));
			while (current != NULL) {
		    		if (id == current->categoria) {
					risultato = 1;
					write(connectSocket, &risultato, sizeof(risultato));
					write(connectSocket, current->titolo, 30);
					write(connectSocket, nomeCategoria(current->categoria), 40);
					write(connectSocket, nomeStato(current->stato), 10);
					listaFiltrata = aggiungiTicketAllaLista(listaFiltrata, current);
		    		}
		    		current = current->next;
			}
			break;
		case 3://Per data
			char query[11];

			// Riceve data dal client come stringa
			read(connectSocket, query, sizeof(query));

			while (current != NULL) {
				char dataStr[11]; //Salva la data del ticket come stringa nel formato "YYYY-MM-DD"
				snprintf(dataStr, sizeof(dataStr), "%04d-%02d-%02d", current->data_creazione.tm_year + 1900, current->data_creazione.tm_mon + 1, current->data_creazione.tm_mday);

				if (strcmp(dataStr, query) == 0) { //La confronta con la stringa inviata dal client
					risultato = 1;
					write(connectSocket, &risultato, sizeof(risultato));
					write(connectSocket, current->titolo, 30);
					write(connectSocket, nomeCategoria(current->categoria), 40);
					write(connectSocket, nomeStato(current->stato), 10);
					listaFiltrata = aggiungiTicketAllaLista(listaFiltrata, current);
				}
				current = current->next;
			}
			break;
		case 4://Per stato
			read(connectSocket, &id, sizeof(int));
			while (current != NULL) {
		    		if (id == current->stato) {
					risultato = 1;
					write(connectSocket, &risultato, sizeof(risultato));
					write(connectSocket, current->titolo, 30);
					write(connectSocket, nomeCategoria(current->categoria), 40);
					write(connectSocket, nomeStato(current->stato), 10);
					listaFiltrata = aggiungiTicketAllaLista(listaFiltrata, current);
		    		}
		    		current = current->next;
			}
			break;
	}
	if (risultato == 0) {
		write(connectSocket, &risultato, sizeof(risultato));  // Nessuna corrispondenza trovata
		return;
	}
	risultato=2; //Fine lettura
	write(connectSocket, &risultato, sizeof(risultato)); 	
	
	int sceltaTicket;
	read(connectSocket, &sceltaTicket, sizeof(sceltaTicket));
	if (sceltaTicket > 0) inviaDettagliTicket(connectSocket, listaFiltrata, sceltaTicket); //Invio i dettagli del ticket selezionato per la stampa 

	//Pulizia memoria lista temporanea
	Ticket *delete;
	while (listaFiltrata) {
		delete = listaFiltrata;
		listaFiltrata = listaFiltrata->next;
		free(delete);
	}

	return;
}

Ticket* aggiungiTicketAllaLista(Ticket* head, Ticket* originale) { //Serve per creare le liste di corrispondenze nella ricerca
	Ticket* nuovo = (Ticket*) malloc(sizeof(Ticket));
	if (!nuovo) return head;

	// Copia tutti i campi
	strcpy(nuovo->titolo, originale->titolo);
	strcpy(nuovo->descrizione, originale->descrizione);
	nuovo->categoria = originale->categoria;
	nuovo->stato = originale->stato;
	nuovo->priorita = originale->priorita;
	nuovo->data_creazione = originale->data_creazione;
	strcpy(nuovo->agente, originale->agente);
	strcpy(nuovo->studente, originale->studente);

	nuovo->next = NULL;

	// Inserisce in coda
	if (head == NULL) {
		return nuovo;
	} else {
		Ticket* tmp = head;
		while (tmp->next != NULL) tmp = tmp->next;
		tmp->next = nuovo;
		return head;
	}
}


void inviaDettagliTicket(int connectSocket, Ticket *matchList, int sceltaTicket) { // Manda al client i dettagli di un ticket
	Ticket *sel = matchList;
	int i = 1;
	while (sel && i < sceltaTicket) {
		sel = sel->next;
		i++;
	}
	if (sel) {
		write(connectSocket, sel->titolo, sizeof(sel->titolo));
		write(connectSocket, sel->descrizione, sizeof(sel->descrizione));
		write(connectSocket, nomeCategoria(sel->categoria), 40); 
		write(connectSocket, nomeStato(sel->stato), 10);
		write(connectSocket, sel->studente, 51);
		write(connectSocket, sel->agente, 51);

		char dataStr[11];
		snprintf(dataStr, sizeof(dataStr), "%04d-%02d-%02d", sel->data_creazione.tm_year + 1900, sel->data_creazione.tm_mon + 1, sel->data_creazione.tm_mday); 
		write(connectSocket, dataStr, 11);
	}
}

void assegnaTicket(int connectSocket, Ticket *headTicket, Utente *headUtente, Utente *utenteLoggato) {
	char comando[20];
	read(connectSocket, comando, sizeof(comando));

	if (strcmp(comando, "LISTA_TICKET") == 0) {
		Ticket *current = headTicket->next;
		Ticket *lista[100]; //Lista di appoggio
		int count = 0;

		while (current != NULL) {
			if (strcmp(current->agente, utenteLoggato->username) == 0) {
				lista[count++] = current;
			}
			current = current->next;
		}
		write(connectSocket, &count, sizeof(int));
		if (count == 0) return; //L'agente non ha ancora ticket
		
		for (int i = 0; i < count; i++) {
			write(connectSocket, lista[i]->titolo, 31); //Invio i titoli
		}
		
		int scelta;
		read(connectSocket, &scelta, sizeof(int)); //Indice del ticket scelto dall'utente

		if (scelta < 1 || scelta > count) { //Scelta non valida
			int fail = 0;
			write(connectSocket, &fail, sizeof(int));
			return;
		}
		Ticket *ticketScelto = lista[scelta - 1];
		
		char nuovoAgente[31];
		read(connectSocket, nuovoAgente, 31); //Agente scelto
		Utente *currentU = headUtente->next;
		int trovato = 0; //Verifico che l'agente esista
		while (currentU != NULL) {
			if (strcmp(currentU->username, nuovoAgente) == 0 && currentU->tipo == 2) {
				trovato = 1;
				break;
			}
			currentU = currentU->next;
		}

		if (!trovato) {
			int fail = 0;
			write(connectSocket, &fail, sizeof(int));
			return;
		} 
		
		//Modifico il ticket
		strncpy(ticketScelto->agente, nuovoAgente, sizeof(ticketScelto->agente));
		ticketScelto->agente[sizeof(ticketScelto->agente)-1] = '\0';

		salvaTicket(headTicket); //Aggiorno la lista

		int ok = 1;
		write(connectSocket, &ok, sizeof(int));
	}
}

void modificaTicket(int connectSocket, Ticket *headTicket, Utente *utenteLoggato) {
	char comando[20];
	read(connectSocket, comando, sizeof(comando));

	if (strcmp(comando, "LISTA_TICKET") == 0) {
		Ticket *current = headTicket->next;
		Ticket *lista[100];
		int count = 0;
		
		while (current != NULL) {
			if (strcmp(current->agente, utenteLoggato->username) == 0) {
				lista[count++] = current;
			}
			current = current->next;
		}
		write(connectSocket, &count, sizeof(int));
		if (count == 0) return; //L'agente non ha ancora ticket

		for (int i = 0; i < count; i++) {
			write(connectSocket, lista[i]->titolo, 31); //Invio i titoli
		}
		
		int sceltaTicket;
		read(connectSocket, &sceltaTicket, sizeof(int)); //Indice del ticket scelto dall'utente
		if (sceltaTicket < 1 || sceltaTicket > count) { //Scelta non valida
			int fail = 0;
			write(connectSocket, &fail, sizeof(int));
			return;
		}
		Ticket *ticketScelto = lista[sceltaTicket - 1];
		
		int sceltaCampo;
		read(connectSocket, &sceltaCampo, sizeof(int)); //Campo da modificare
		int nuovoValore;
		read(connectSocket, &nuovoValore, sizeof(int)); //Valore da inserire

		if (sceltaCampo == 1) { // Modifica stato
			if (nuovoValore >= 1 && nuovoValore <= 3) {
				ticketScelto->stato = nuovoValore;
			}
		} else if (sceltaCampo == 2) { // Modifica priorità
			if (nuovoValore >= 1 && nuovoValore <= 3) {
				ticketScelto->priorita = nuovoValore;
			}
		}

		salvaTicket(headTicket); //Aggiorno la lista

		int ok = 1;
		write(connectSocket, &ok, sizeof(int));
	}
}

